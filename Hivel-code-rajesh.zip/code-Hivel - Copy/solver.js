const fs = require('fs');

/**
 * Reads and parses a JSON file
 * @param {string} filename - Path to the JSON file
 * @returns {Object} Parsed JSON object
 */
function readJSONFile(filename) {
    try {
        const data = fs.readFileSync(filename, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error(`Error reading file ${filename}:`, error.message);
        process.exit(1);
    }
}

/**
 * Decodes a value string from its base
 * @param {string} valueString - The encoded value string
 * @param {string} baseString - The base as a string
 * @returns {number} Decoded integer value
 */
function decodeValue(valueString, baseString) {
    const base = parseInt(baseString, 10);
    return parseInt(valueString, base);
}

/**
 * Decodes all Y values from the JSON data
 * @param {Object} data - Parsed JSON data
 * @returns {Array<{x: number, y: number}>} Array of points (x, y)
 */
function decodeAllValues(data) {
    const points = [];
    const keys = Object.keys(data).filter(key => key !== 'keys');
    
    // Sort keys numerically to ensure correct order
    keys.sort((a, b) => parseInt(a, 10) - parseInt(b, 10));
    
    for (const key of keys) {
        const entry = data[key];
        const x = parseInt(key, 10);
        const y = decodeValue(entry.value, entry.base);
        points.push({ x, y });
    }
    
    return points;
}

/**
 * Computes the Lagrange basis polynomial L_i(0)
 * @param {number} i - Index of the point
 * @param {Array<{x: number, y: number}>} points - All points
 * @returns {number} Value of L_i(0)
 */
function lagrangeBasisAtZero(i, points) {
    let numerator = 1;
    let denominator = 1;
    const xi = points[i].x;
    
    for (let j = 0; j < points.length; j++) {
        if (j !== i) {
            numerator *= (0 - points[j].x);
            denominator *= (xi - points[j].x);
        }
    }
    
    return numerator / denominator;
}

/**
 * Reconstructs polynomial using Lagrange interpolation and finds constant term
 * @param {Array<{x: number, y: number}>} points - All points
 * @param {number} k - Number of points to use (first k points)
 * @returns {number} Constant term C of the polynomial
 */
function reconstructPolynomial(points, k) {
    // Use only the first k points
    const selectedPoints = points.slice(0, k);
    
    // Compute constant term using Lagrange interpolation: P(0) = Σ(y_i * L_i(0))
    let constantTerm = 0;
    
    for (let i = 0; i < selectedPoints.length; i++) {
        const li = lagrangeBasisAtZero(i, selectedPoints);
        constantTerm += selectedPoints[i].y * li;
    }
    
    return constantTerm;
}

/**
 * Main function to solve the polynomial reconstruction problem
 * @param {string} filename - Path to the JSON test case file
 */
function solve(filename) {
    // Step 1: Read JSON file
    const data = readJSONFile(filename);
    
    // Extract keys
    const n = data.keys.n;
    const k = data.keys.k;
    
    // Step 2: Decode all Y values
    const points = decodeAllValues(data);
    
    // Step 3: Reconstruct polynomial and find constant term
    const constantTerm = reconstructPolynomial(points, k);
    
    // Step 4: Output the constant term
    console.log(`C = ${constantTerm}`);
}

// Get filename from command line argument or use default
const filename = process.argv[2] || 'testcase1.json';

// Run the solver
solve(filename);

